'''Extract the vowel which has max count'''
#Question_1

# s = input()
# list = ['a','e','i','o','u']
# count = 0
# for i in s:
#     if i in list:
#         count += 1
#         max(list)
# print(count)
# print(max(list))



#Question_2

# from collections import Counter
# str = "hello worlde"
# str = list(str)
# for i in str:
#     if i in "aeiou":
#         s = i
# str.remove(s)
# s1 = str.index(s)
# print(s1+1)

#Questions_3
