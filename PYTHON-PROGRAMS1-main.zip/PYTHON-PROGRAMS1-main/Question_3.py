'''
Max is having a dog . he want  to find the age of the dog  with respect to the age of human.
he came to know that , the age of the  dog is mesured with respect to human  has a formula to proceed. 
example: 1 year of life span of dog is same as seveen years of  life span  of human being
Now , calculate the age of MAX dog.
'''

def dog():
    n=int(input())
    return n*7
print(dog())