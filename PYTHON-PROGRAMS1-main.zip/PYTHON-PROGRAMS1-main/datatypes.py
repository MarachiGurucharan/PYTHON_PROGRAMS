a=10.0
b=20
c="Manoj"
d=True
print(type(a))
print(type(b))
print(type(c))
print(type(d))