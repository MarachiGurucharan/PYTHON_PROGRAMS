# input_statement = input("Enter a statement: ")

# number_of_spaces = input_statement.count(' ')

# print(f"The number of spaces in the statement is: {number_of_spaces}")

